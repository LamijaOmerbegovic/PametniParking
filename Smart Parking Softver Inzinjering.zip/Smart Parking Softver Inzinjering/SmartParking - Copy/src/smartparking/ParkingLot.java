/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smartparking;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author 38762
 */
@Entity
@Table(name = "parkinglot")
public class ParkingLot{
    @Column(name = "parkingspot")
    private int parkingspot;
    @Column(name = "freeparkingspot")
    private int freeparkingspot;
    @Column(name = "price")
    private double price;
    @Column(name = "name")
    private String name;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "parkinglot_id")
    private int parkinglot_id;

    public ParkingLot() {
    }

    public ParkingLot(int parkingspot, int freeparkingspot, double price, String name) {
        this.parkingspot = parkingspot;
        this.freeparkingspot = freeparkingspot;
        this.price = price;
        this.name = name;
    }

    public int getParkingspot() {
        return parkingspot;
    }

    public void setParkingspot(int parkingspot) {
        this.parkingspot = parkingspot;
    }

    public int getFreeparkingspot() {
        return freeparkingspot;
    }

    public void setFreeparkingspot(int freeparkingspot) {
        this.freeparkingspot = freeparkingspot;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getParkinglot_id() {
        return parkinglot_id;
    }

    public void setParkinglot_id(int parkinglot_id) {
        this.parkinglot_id = parkinglot_id;
    }

    @Override
    public String toString() {
        return "ParkingLot{" + "parkingspot=" + parkingspot + ", freeparkingspot=" + freeparkingspot + ", price=" + price + ", name=" + name + ", parkinglot_id=" + parkinglot_id + '}';
    }
}
